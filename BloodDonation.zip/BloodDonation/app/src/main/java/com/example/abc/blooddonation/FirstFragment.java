package com.example.abc.blooddonation;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class FirstFragment extends Fragment {

Button bt3;
    EditText e1,e2;
    public FirstFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View view=inflater.inflate(R.layout.fragment_first, container, false);
        bt3= view.findViewById(R.id.button3);
        e1= view.findViewById(R.id.emailId);
        e2= view.findViewById(R.id.pwtxt);
        
        
        
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1=e1.getText().toString();
                String s2=e2.getText().toString();
                
               if( s1.indexOf("@")==0)
               {
                   Toast.makeText(getActivity(), "invalid email", Toast.LENGTH_SHORT).show();
               }
                if(s1.indexOf(".")==0)
                {
                    Toast.makeText(getActivity(), "invalid email", Toast.LENGTH_SHORT).show();
                }
                
            }
        });
        Toast.makeText(getActivity(), "Login successfull", Toast.LENGTH_SHORT).show();

        return view;

    }

}
