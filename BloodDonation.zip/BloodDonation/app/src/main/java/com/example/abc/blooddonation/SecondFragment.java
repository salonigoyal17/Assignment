package com.example.abc.blooddonation;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class SecondFragment extends Fragment {
Button bt4;
    EditText nam,phn,eid,pass;

    public SecondFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_second, container, false);
        bt4= view.findViewById(R.id.button4);
        nam=view.findViewById(R.id.name);
        phn= view.findViewById(R.id.phone);
        eid=view.findViewById(R.id.email);
        pass=view.findViewById(R.id.paswd);

        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1=nam.getText().toString();
                String s2= eid.getText().toString();
                String s3= phn.getText().toString();

                if( s2.indexOf("@")==0)
                {
                    Toast.makeText(getActivity(), "invalid email", Toast.LENGTH_SHORT).show();
                }
                if(s2.indexOf(".")==0)
                {
                    Toast.makeText(getActivity(), "invalid email", Toast.LENGTH_SHORT).show();
                }
                if(s3.length()>10)
                {
                    Toast.makeText(getActivity(), "invalid number", Toast.LENGTH_SHORT).show();
                }
                if(s1.length()==0)
                {
                    Toast.makeText(getActivity(), "fill your name", Toast.LENGTH_SHORT).show();
                }


            }
        });
        Toast.makeText(getActivity(), "Register successfull", Toast.LENGTH_SHORT).show();




        return view;
    }

}
